package qa;

public class QuickSort2 {
	int[] nums;
	int[] helper;
	int size;
	
	public void doQuickSort(int[] nums){
		int low = 0;
		int high = nums.length-1;
		
		
	}
	
	
	
	
	
	
	/**
	 * @param args
	 */
	public static void main(String[] args) {
		QuickSort2 mc = new QuickSort2();
		int[] nums = {1,5,23,5,67,7,8,2};
		mc.doQuickSort(nums);
		
		
		
		
		
	}

}

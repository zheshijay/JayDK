package qa;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Queue;
import java.util.Stack;

public class BuildTreeFromList {  


//    linkedin-interview-questions
//    0
//    of 0 votes
//    11
//    Answers
//
//    Given a list of child->parent relationships, build a binary tree out of it. All the element Ids inside the tree are unique.
//
//    Example:
//
//    Given the following relationships:
//
//    Child Parent IsLeft
//    15 20 true
//    19 80 true
//    17 20 false
//    16 80 false
//    80 50 false
//    50 null false
//    20 50 true
//
//
//    You should return the following tree:
//    	 50
//    	/  \
//      20    80
//     / \   /  \
//    15 17  19 16
//
//
//    Function Signature
//
//
//    /**
//    * Represents a pair relation between one parent node and one child node inside a binary tree
//    * If the _parent is null, it represents the ROOT node
//    */
//    public class Relation {
//    public Integer _parent;
//    public Integer _child;
//    public boolean _isLeft;
//    }
//
//
//    /**
//    * Represents a single Node inside a binary tree
//    */
//    public class Node {
//    public Integer _id;
//    public Node _left;
//    public Node _right;
//    }
//
//    /**
//    * Implement a method to build a tree from a list of parent-child relationships
//    * And return the root Node of the tree
//    */
//    public Node buildTree (List<Relation> data)
//    {
//    }
//    - prashanti1902 March 18, 2015 in United States | Report Duplicate | Flag 



	/**
	 * Represents a single Node inside a binary tree
	 */
	public class Node {
		public Integer _id;
		public Node _left;
		public Node _right;
	}

	/**
	 * Implement a method to build a tree from a list of parent-child relationships
	 * And return the root Node of the tree
	 */
	public Node buildTree (List<Relation> data)
	{
		HashMap<Integer, Integer> leftMap = new HashMap<>();
		HashMap<Integer, Integer> rightMap = new HashMap<>();
		
		Node head = new Node();
		
		for (Relation i:data) {
			System.out.println(" ------------------------------------------- ");
			System.out.println("Processing i _child: " + i._child);
			System.out.println("Processing i _isLeft: " + i._isLeft);
			
			if (i._isLeft) {
				System.out.println("[Put to left]");
				System.out.println("-- _parent: " + i._parent);
				System.out.println("-- _child: " + i._child);
				
				leftMap.put(i._parent, i._child);
			} else {
				System.out.println("[Put to right]");
				System.out.println("-- _parent: " + i._parent);
				System.out.println("-- _child: " + i._child);
				
				rightMap.put(i._parent, i._child);
			}
			if (i._parent==null) {
				System.out.println("[****Found root****]");
				head._id = i._child;
			}
		}
		
		System.out.println("============> head:" + head._id);
		

		java.util.Stack<Node> stack = new Stack<>();
		stack.push(head);
		while (!stack.empty()) {
			Node tracker = stack.pop();
			if (rightMap.containsKey(tracker._id)) {
				tracker._right = new Node();
				tracker._right._id = rightMap.get(tracker._id);
				stack.push(tracker._right);
			}
			if (leftMap.containsKey(tracker._id)) {
				tracker._left = new Node();
				tracker._left._id = leftMap.get(tracker._id);
				stack.push(tracker._left);
			}
		}
		return head;
	}

	public static void main(String[] args){

		List<Relation> relations = new ArrayList<Relation>();

		Relation r1 = new Relation(15, 20, true);
		Relation r2 = new Relation(19, 80, true);
		Relation r3 = new Relation(17, 20, false);
		Relation r4 = new Relation(16, 80, false);
		Relation r5 = new Relation(80, 50, false);
		Relation r6 = new Relation(50, null, false);
		Relation r7 = new Relation(20, 50, true);

		relations.add(r1);
		relations.add(r2);
		relations.add(r3);
		relations.add(r4);
		relations.add(r5);
		relations.add(r6);
		relations.add(r7);

		BuildTreeFromList myclass = new BuildTreeFromList();
		Node root = myclass.buildTree(relations);
		
		System.out.println("root is null: " + (root == null));
		
		System.out.println("left child of root is: " + root._left);
		
		myclass.printTree(root);


	}

	private void printTree(Node root) {

		if(root == null) return;
		System.out.print(root._id + " ");
		printTree(root._left);
		printTree(root._right);
	}
}


/**
 * Represents a pair relation between one parent node and one child node inside a binary tree
 * If the _parent is null, it represents the ROOT node
 */
class Relation {
	public Integer _parent;
	public Integer _child;
	public boolean _isLeft;

	public Relation(Integer child, Integer parent, boolean isLeft){
		this._isLeft = isLeft;
		this._parent = parent;
		this._child = child;
	}
}
package qa;

public class MergeSort2 {

}

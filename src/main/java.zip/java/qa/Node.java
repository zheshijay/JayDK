package qa;

public class Node {
	public int val;
	Node left=null, right=null;
	Node(int val){
		this.val = val;
	}
	
}

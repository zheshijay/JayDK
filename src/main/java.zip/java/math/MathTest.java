package math;

public class MathTest {
	public static void main(String[] args){
		System.out.println(460/230);
	}
}

package notification;

public class Batch {
	
	public static void main(String[] args) {
		System.out.println("123");
		try {
//			String apiURL = "https://pd-dev2.infoimageinc.com:9880/notifyservice/api/v1/notification";
			String apiURL = "https://infocloud01.infoimageinc.com:9880/notifyservice/api/v1/notification/";
			String orgName = "hebc";
			// "{\"app\": \"estmt\",\"templateid\": 501,\"type\":\"sms\", \"to\": \"4152032591\", \"carrier\": \"tmobile\" }";
			String cName = "Test Campaign";
			String app = "estmt";
			String csvId = "88a6c300-a775-11e4-a79b-000c29af2cb6";
			String priority = "normal";
			String isSent = NotificationManager.sendBatch(apiURL, orgName, cName, app, csvId, priority);
			
			
			System.out.println("isSent: " + isSent);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

}

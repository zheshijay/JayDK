package notification;

public class OnDemandBackup {
	
	public static void main(String[] args) {
		System.out.println("123");
		try {
			String apiURL = "https://pd-dev2.infoimageinc.com:9880/notifyservice/api/v1/notification";
//			String apiURL = "https://infocloud01.infoimageinc.com:9880/notifyservice/api/v1/notification/";
			String orgName = "rwcu";
			// "{\"app\": \"estmt\",\"templateid\": 501,\"type\":\"sms\", \"to\": \"4152032591\", \"carrier\": \"tmobile\" }";
			RealTimeNotification sms = new RealTimeNotification();
			sms.setApp("marketing");
			sms.setTemplateid("481");
//			sms.setType("sms");
//			sms.setTo("7148242485");
			sms.setType("sms");
			sms.setTo("7148242485");
			sms.setCarrier("tmobile");
//			Map<String, String> vars = new HashMap<String, String>();
//			vars.put("${testOne}", "123");
//			vars.put("${testTwo}", "234");
//			sms.setVars(vars);
			boolean isSent = NotificationManager.sendOnDemand(apiURL, orgName, sms);
			
			System.out.println("isSent: " + isSent);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

}

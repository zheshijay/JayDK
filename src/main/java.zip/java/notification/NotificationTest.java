package notification;

import java.util.HashMap;
import java.util.Map;

public class NotificationTest {
	
	public static void main(String[] args) {
		try {
//			String apiURL = "https://pd-pilot1.infoimageinc.com:9580/notifyservice/api/v1/notification";
			String apiURL = "http://pd-dev7.infoimage.com:8580/notifyservice/api/v1/notification";
//			String apiURL = "https://infocloud01.infoimageinc.com:9880/notifyservice/api/v1/notification/";
//			String orgName = "abak";
			String orgName = "demo";
			// "{\"app\": \"estmt\",\"templateid\": 501,\"type\":\"sms\", \"to\": \"4152032591\", \"carrier\": \"tmobile\" }";
			RealTimeNotification real = new RealTimeNotification();
//			real.setApp("marketing");
			real.setApp("marketing");
//			real.setTemplateid("2443");
			real.setTemplateid("2103");
			
//			real.setType("sms");
			real.setType("email");
//			real.setReplyTo("12137618058");
//			real.setfEmail("12105190241");
//			real.setTo("17148242485"); //T-Mobile
//			real.setTo("12137618058"); //Google Voice
//			real.setTo("15149983500");
//			real.setTo("4089133738"); //Alok
//			real.setTo("18135057825"); //Rohit

//			real.setCarrier("att");
//			real.setType("email");
			real.setTo("Zhe.Shi@infoimageinc.com");
			real.setCarrier("na");
//			real.setCarrier("tmobile");
			
			Map<String, String> vars = new HashMap<String, String>();
			vars.put("udv_txt_smsv_code", "1234");
//			vars.put("${testTwo}", "234");
			real.setVars(vars);
			System.out.println("Send SMS/Email");
//			boolean isSent = NotificationManager.sendOnDemand(apiURL, orgName, sms);
			boolean isSent = NotificationManager.sendOnDemandwithTrack(apiURL, orgName, real);
			System.out.println("isSent: " + isSent);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}

package notification;

import java.util.HashMap;
import java.util.Map;

public class SMSVerification {
	
	public static void main(String[] args) {
		try {
//			String apiURL = "https://pd-pilot1.infoimageinc.com:9580/notifyservice/api/v1/notification";
			String apiURL = "https://pd-dev2.infoimageinc.com:9880/notifyservice/api/v1/notification";
//			String apiURL = "http://localhost:8081/notifyservice/api/v1/notification";
//			String apiURL = "https://infocloud01.infoimageinc.com:9880/notifyservice/api/v1/notification/";
			String orgName = "fffc";
			// "{\"app\": \"estmt\",\"templateid\": 501,\"type\":\"sms\", \"to\": \"4152032591\", \"carrier\": \"tmobile\" }";
			RealTimeNotification sms = new RealTimeNotification();
//			sms.setApp("marketing");
			sms.setApp("estmt");
			sms.setTemplateid("3261");
			sms.setType("sms");
//			sms.setReplyTo("12137618058");
			sms.setfEmail("12105190241");
			sms.setTo("17148242485");
//			sms.setTo("12137618058");
//			sms.setTo("14089133738"); //Alok
//			sms.setTo("18135057825"); //Rohit
//			sms.setCarrier("tmobile");
			sms.setCarrier("na");
//			sms.setCarrier("att");
			sms.setType("sms");
//			sms.setTo("Zhe.Shi@infoimageinc.com");
//			sms.setCarrier("tmobile");
			Map<String, String> vars = new HashMap<String, String>();
			vars.put("udv_txt_smsv_code", "8356");
//			vars.put("${testTwo}", "234");
			sms.setVars(vars);
			System.out.println("Send SMS/Email");
			boolean isSent = NotificationManager.sendOnDemand(apiURL, orgName, sms);
			
			System.out.println("isSent: " + isSent);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}

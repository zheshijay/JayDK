package notification.batchProcess.Batch;

import java.io.File;


public class CSV {
	
	public static void main(String[] args) {
		System.out.println("START");
		try {
			// download csv start
//			String apiURL = "https://pd-dev2.infoimageinc.com:9880/notifyservice/api/v1/notification/";
//			apiURL = "https://infocloud01.infoimageinc.com:9580/notifyservice/api/v1/notification/";
////			String apiURL = APIProperties.getInstance().getProperty("com.infoimage.apiurl.csv");
//			System.out.println("apiURL: " + apiURL);
//			String orgName = "hebc";
//			String uuId = "6253c7b0-a744-11e4-ab2b-b260a9b7b821";
//			String fileName = "test.csv";
//			CsvManager.readCsv(apiURL, orgName, uuId, fileName);
			// download csv end
			
			// upload csv start
			String apiURL = "https://pd-dev2.infoimageinc.com:9880/infoscanner/api/v1/notification/";
//			apiURL = "https://infoscanner.infoimageinc.com:9580/infoscanner/api/v1/notification/";
			System.out.println("apiURL: " + apiURL);
			String orgName = "ewbb";
			String fileName = "C:/tmp/csvfiles/TfileuploadAttachment3.csv";
			File file = new File(fileName);
			String csvId = CsvManager.uploadCsv(apiURL, orgName, file);
			System.out.println("csvId: " + csvId);
			// upload csv end
		} catch (Exception e) {
			e.printStackTrace();
		}
		System.out.println("END");
	}

}

package notification.batchProcess.Batch;
import notification.NotificationManager;
public class Batch {
	
	public static void main(String[] args) {
		System.out.println("123");
		try {
			String apiURL = "https://pd-dev2.infoimageinc.com:9880/notifyservice/api/v1/notification";
//			String apiURL = "https://infocloud01.infoimageinc.com:9880/notifyservice/api/v1/notification/";
			String orgName = "ewbb";
			// "{\"app\": \"estmt\",\"templateid\": 501,\"type\":\"sms\", \"to\": \"4152032591\", \"carrier\": \"tmobile\" }";
			String cName = "Test Campaign";
			String app = "estmt";
			String csvId = "b1a5cdf0-4aa9-11e5-ab45-cabaab161da2";
			String priority = "normal";
			String isSent = NotificationManager.sendBatch(apiURL, orgName, cName, app, csvId, priority);
			
			System.out.println("isSent: " + isSent);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

}

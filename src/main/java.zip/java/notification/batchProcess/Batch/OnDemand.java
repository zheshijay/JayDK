package notification.batchProcess.Batch;

import notification.NotificationManager;
import notification.RealTimeNotification;



public class OnDemand {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		try {
			String apiURL = "http://pd-dev2.infoimageinc.com:8880/notifyservice/api/v1/notification";
//			String apiURL = "https://infocloud01.infoimageinc.com:9880/notifyservice/api/v1/notification/";
			String orgName = "epcu";
			// "{\"app\": \"estmt\",\"templateid\": 501,\"type\":\"sms\", \"to\": \"4152032591\", \"carrier\": \"tmobile\" }";
			RealTimeNotification sms = new RealTimeNotification();
			sms.setApp("estmt");
			sms.setTemplateid("2426");
			sms.setType("sms");
//			sms.setfEmail("12105190241");
			sms.setTo("14152032591");
			sms.setCarrier("na");
//			Map<String, String> vars = new HashMap<String, String>();
//			vars.put("${testOne}", "123");
//			vars.put("${testTwo}", "234");
//			sms.setVars(vars);
			boolean isSent = NotificationManager.sendOnDemand(apiURL, orgName, sms);
			
			System.out.println("isSent: " + isSent);
		} catch (Exception e) {
			e.printStackTrace();
		}
		System.out.println("== start  123");
	}

}

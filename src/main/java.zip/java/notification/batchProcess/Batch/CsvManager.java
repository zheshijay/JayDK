package notification.batchProcess.Batch;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.lang.reflect.Type;
import java.util.Map;

import javax.ws.rs.core.MediaType;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.sun.jersey.api.client.Client;
import com.sun.jersey.api.client.ClientResponse;
import com.sun.jersey.api.client.WebResource;
import com.sun.jersey.multipart.FormDataMultiPart;
import com.sun.jersey.multipart.file.FileDataBodyPart;

public class CsvManager {
	
	public static String uploadCsv(String apiURL, String orgName, File file) {
		String csvId = null;
		try {
			FormDataMultiPart formDataMultiPart = new FormDataMultiPart();
			formDataMultiPart.bodyPart(new FileDataBodyPart("file", file, MediaType.MULTIPART_FORM_DATA_TYPE));
			formDataMultiPart.field("fileName", file.getName());
			
			Client client = new Client();
			WebResource webResource = client.resource(apiURL);
			ClientResponse response = webResource.path("upload").path(orgName).type(MediaType.MULTIPART_FORM_DATA_TYPE).post(ClientResponse.class, formDataMultiPart);
			int status = response.getStatus();
			String responseStr = response.getEntity(String.class);
			if (status == 200) {
				System.out.println("csv file successfully uploaded");
				Gson gson = new Gson();
				Type mapType = new TypeToken<Map<String, String>>(){}.getType();
				Map<String, String> resultMap = gson.fromJson(responseStr, mapType);
				csvId = resultMap.get("uuid");
			} else {
				System.out.println("status: " + status);
				System.out.println("responseStr: " + responseStr);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return csvId;
	}
	
	public static void readCsv(String apiURL, String orgName, String uuId, String fileName) {
		try {
			Client client = new Client();
			WebResource webResource = client.resource(apiURL);
			ClientResponse response = webResource.path(orgName).path("job").path(uuId).path("download").queryParam("csvName", fileName).type(MediaType.MULTIPART_FORM_DATA_TYPE).get(ClientResponse.class);
			if (response.getStatus() != 200) {
				throw new Exception("response: " + response.getStatus());
			}
			File src = response.getEntity(File.class);
			BufferedReader reader = null;
			BufferedWriter writer = null;
			try {
				reader = new BufferedReader(new FileReader(src));
				File dest = new File(fileName);
				writer = new BufferedWriter(new FileWriter(dest));
				String line = "";
				while ((line = reader.readLine()) != null) {
					writer.write(line + "\n");
				}
			} catch (Exception e) {
				e.printStackTrace();
			} finally {
				reader.close();
				writer.close();
			}
			int status = response.getStatus();
			String responseStr = response.getEntity(String.class);
			if (status == 200) {
				System.out.println("csv file successfully downloaded");
			} else {
				System.out.println("status: " + status);
				System.out.println("responseStr: " + responseStr);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

}

package notification.batchProcess.Batch;

import java.lang.reflect.Type;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.ws.rs.core.MediaType;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.reflect.TypeToken;
import com.sun.jersey.api.client.Client;
import com.sun.jersey.api.client.ClientResponse;
import com.sun.jersey.api.client.WebResource;
import com.sun.jersey.core.util.MultivaluedMapImpl;

public class NotificationTemplateManager {
	
	// API Supported system defined variable
	public static final String ACCTNUM = "sdv_txt_acctNum";
	public static final String ENOTICELIST = "sdv_txt_eNoticeList";
	public static final String ETAXLIST = "sdv_txt_eTaxList";
	public static final String USERNAME = "sdv_txt_userName";
	
	private static final String templateDateFormat = "yyyy-MM-dd HH:mm";
	
	/**
	 * Retrieve the first matching notificationTemplate by providing all details
	 * @param apiURL
	 * @param orgName
	 * @param appId
	 * @param type
	 * @param templateId
	 * @param templateName
	 * @param status
	 * @return
	 */
	public static NotificationTemplate getNotificationTemplate(String apiURL, String orgName, String appId, String type, String templateId, String templateName, String status) {
		Map<String, String> optionalParams = new HashMap<String, String>();
		if (type != null && !type.trim().equals("")) {
			optionalParams.put("type", type);
		}
		if (templateId != null && !templateId.trim().equals("")) {
			optionalParams.put("templateId", templateId);
		}
		if (templateName != null && !templateName.trim().equals("")) {
			optionalParams.put("templateName", templateName);
		}
		if (status != null && !status.trim().equals("")) {
			optionalParams.put("status", status);
		}
		List<NotificationTemplate> templates = getNotificationTemplates(apiURL, orgName, appId, optionalParams);
		if (templates.size() == 0) {
			System.out.println("No templates match to the search criteria");
			return null;
		}
		return templates.get(0);
	}
	
	/**
	 * Retrieve all notificationTemplates based on all the available params
	 * @param apiURL
	 * @param orgName
	 * @param appId
	 * @param optionalParams
	 * @return
	 */
	public static List<NotificationTemplate> getNotificationTemplates(String apiURL, String orgName, String appId, Map<String, String> optionalParams) {
		List<NotificationTemplate> templates = null;
		try {
			Client client = new Client();
			WebResource webResource = client.resource(apiURL);
			MultivaluedMapImpl queryParams = new MultivaluedMapImpl();
			queryParams.add("clientId", orgName);
			queryParams.add("appId", appId);
			if (optionalParams != null) {
				for (String optionalParam: optionalParams.keySet()) {
					queryParams.add(optionalParam, optionalParams.get(optionalParam));
				}
			}
			ClientResponse response = webResource.path(orgName).path("template").queryParams(queryParams).type(MediaType.APPLICATION_JSON_TYPE).accept(MediaType.APPLICATION_JSON).get(ClientResponse.class);
			int status = response.getStatus();
			String jsonResponse = response.getEntity(String.class);
			if (status == 200) {
				System.out.println("jsonResponse: " + jsonResponse);
				Gson gson = new GsonBuilder().setDateFormat(templateDateFormat).create();
				Type templateType = new TypeToken<List<NotificationTemplate>>(){}.getType();
				templates = gson.fromJson(jsonResponse, templateType);
			} else {
				System.out.println("jsonResponse: " + jsonResponse);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return templates;
	}
	
	public static String insertNotificationTemplate(String apiURL, String orgName, NotificationTemplate template) {
		String templateId = null;
		try {
			Gson gson = new GsonBuilder().setDateFormat(templateDateFormat).create();
			String jsonStr = gson.toJson(template);
			Client client = new Client();
			WebResource webResource = client.resource(apiURL);
			ClientResponse response = webResource.path(orgName).path("template").type(MediaType.APPLICATION_JSON_TYPE).accept(MediaType.APPLICATION_JSON).post(ClientResponse.class, jsonStr);
			int status = response.getStatus();
			String responseStr = response.getEntity(String.class);
			if (response.getStatus() == 200) {
				System.out.println("response: " + responseStr);
				Type mapType = new TypeToken<Map<String, String>>(){}.getType();
				Map<String, String> result = gson.fromJson(responseStr, mapType);
				if (result.get("result").equals("true")) {
					templateId = result.get("notifTemplateId");
				}
			} else {
				System.out.println("Status: " + status);
				System.out.println("response: " + responseStr);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return templateId;
	}
	
	public static boolean updateNotificationTemplate(String apiURL, String orgName, String appId, String type, String templateId, NotificationTemplate template) {
		boolean isUpdated = false;
		try {
			Gson gson = new GsonBuilder().setDateFormat(templateDateFormat).create();
			String jsonStr = gson.toJson(template);
			Client client = new Client();
			WebResource webResource = client.resource(apiURL);
			MultivaluedMapImpl queryParams = new MultivaluedMapImpl();
			queryParams.add("clientId", orgName);
			queryParams.add("appId", appId);
			queryParams.add("type", type);
			queryParams.add("notifTemplateId", templateId);
			ClientResponse response = webResource.path(orgName).path("template").queryParams(queryParams).type(MediaType.APPLICATION_JSON_TYPE).accept(MediaType.APPLICATION_JSON).put(ClientResponse.class, jsonStr);
			int status = response.getStatus();
			String jsonResponse = response.getEntity(String.class);
			if (status == 200) {
				Type mapType = new TypeToken<Map<String, String>>(){}.getType();
				Map<String, String> result = gson.fromJson(jsonResponse, mapType);
				isUpdated = (result.get("result").equals("true"));
			} else {
				System.out.println("jsonResponse: " + jsonResponse);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return isUpdated;
	}

}

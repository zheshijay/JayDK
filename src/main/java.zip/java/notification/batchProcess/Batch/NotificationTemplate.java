package notification.batchProcess.Batch;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;

public class NotificationTemplate {
	
	protected Date modifiedDate;
	protected String modifiedBy;
	protected String id;
	protected String type;
	protected String appId;
	protected String subject;
	protected String fromEmail;
	protected String fromName;
	protected String name;
	protected String ccEmail;
	protected String bccEmail;
	protected String content;
	protected String clientId;
	protected String status;
	protected String sampleRecipient;
	protected Map<String, String> tempVars;

	public Date getModifiedDate() {
		return modifiedDate;
	}
	public void setModifiedDate(Date modifiedDate) {
		this.modifiedDate = modifiedDate;
	}
	public String getModifiedBy() {
		return modifiedBy;
	}
	public void setModifiedBy(String modifiedBy) {
		this.modifiedBy = modifiedBy;
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public String getAppId() {
		return appId;
	}
	public void setAppId(String appId) {
		this.appId = appId;
	}
	public String getSubject() {
		return subject;
	}
	public void setSubject(String subject) {
		this.subject = subject;
	}
	public String getFromEmail() {
		return fromEmail;
	}
	public void setFromEmail(String fromEmail) {
		this.fromEmail = fromEmail;
	}
	public String getFromName() {
		return fromName;
	}
	public void setFromName(String fromName) {
		this.fromName = fromName;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getCcEmail() {
		return ccEmail;
	}
	public void setCcEmail(String ccEmail) {
		this.ccEmail = ccEmail;
	}
	public String getBccEmail() {
		return bccEmail;
	}
	public void setBccEmail(String bccEmail) {
		this.bccEmail = bccEmail;
	}
	public String getContent() {
		return content;
	}
	public void setContent(String content) {
		this.content = content;
	}
	public String getClientId() {
		return clientId;
	}
	public void setClientId(String clientId) {
		this.clientId = clientId;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getSampleRecipient() {
		return sampleRecipient;
	}
	public void setSampleRecipient(String sampleRecipient) {
		this.sampleRecipient = sampleRecipient;
	}
	public Map<String, String> getTempVars() {
		return new HashMap<String, String>(tempVars);
	}
	public void setTempVars(Map<String, String> tempVars) {
		this.tempVars = new HashMap<String, String>(tempVars);
	}

}
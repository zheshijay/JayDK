package notification.batchProcess.Batch;

import java.util.HashMap;
import java.util.List;
import java.util.Map;


public class Template {
	
	public static void insertTemplate(String apiURL) {
		String templateId = "";
		NotificationTemplate template = null; 
		template = new NotificationTemplate();
		template.setClientId("epcu");
		template.setFromName("12105190241");
		template.setFromEmail("12105190241");
		template.setSubject("TFCU e-Notify");
		template.setName("Monthly Statements");
		template.setAppId("estmt");
		template.setType("sms");
		String emailContent = "Your TFCU e-Statement is now available. Please go to \nhttps://www.tfcu.coop/ to view it. Thank you.";
		// While converting all existing eStatement supported keyword to API standard, need to ensure to append the "$" to the beginning of the keyword as it's required in the template
		template.setContent(emailContent);
		template.setStatus("active");
		templateId = NotificationTemplateManager.insertNotificationTemplate(apiURL, "epcu", template);
		System.out.println("templateId: " + templateId);
	}
	
	public static void main(String[] args) {
		System.out.println("START");
		String orgName = "epcu";
//		String apiURL = "https://pd-dev2.infoimageinc.com:9880/templateservice/api/v1/notiftmplmgmt/";
		String apiURL = "https://pd-pilot1.infoimageinc.com:9580/templateservice/api/v1/notiftmplmgmt/";
//		String apiURL = "https://infocloud01.infoimageinc.com:9880/templateservice/api/v1/notiftmplmgmt/";
		System.out.println("apiURL: " + apiURL);
//		NotificationTemplate template = new NotificationTemplate();
//		template.setClientId("demo");
//		template.setFromName("PoHao Su");
//		template.setFromEmail("pohao.su@infoimageinc.com");
//		template.setSubject("Test Email");
//		template.setName("Test Template");
//		template.setAppId("estmt");
//		template.setType("email");
//		template.setContent("This is email testing");
//		template.setStatus("active");
		
		Template.insertTemplate(apiURL);
		
		
//		boolean isUpdated = NotificationTemplateManager.updateNotificationTemplate(apiURL, orgName, "estmt", "sms", "101", template);
//		System.out.println("isUpdated:  " + isUpdated);
		
		
		
		//544 for email
		//545 for sms
//		System.out.println("templateId:  " + templateId);
//		Map<String, String> optionalParams = new HashMap<String, String>();
//		optionalParams.put("type", "email");
//		optionalParams.put("notifTemplateName", "Monthly Statements");
//		optionalParams.put("status", "active");
//		// below two params should be supported in the coming future in order to ensure that the first return result should always be the latest copy of the content
//		optionalParams.put("sort", "modifiedDate");
//		optionalParams.put("order", "desc");
//		// API should be sorted by the modifiedTime in the descending order. Therefore, when multiple templates returned, we'll take the first one as it's the last approved template.
//		List<NotificationTemplate> templates = NotificationTemplateManager.getNotificationTemplates(apiURL, "epcu", "estmt", optionalParams);
//		for (NotificationTemplate temp: templates) {
//			System.out.println("template: " + temp.getId());
//		}
		System.out.println("END");
	}

}

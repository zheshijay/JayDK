package mongo.utils;

import java.net.UnknownHostException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import com.mongodb.BasicDBObject;
import com.mongodb.DBCollection;
import com.mongodb.DBCursor;
import com.mongodb.DBObject;
import com.mongodb.MongoClient;

public class MongoTest {
	
	private static MongoClient mongo = null;
	DateFormat dateFormatter = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
	
	MongoConnector mongoConnector = new MongoConnector();
	public DBCollection getDBCollection(String collName){
		try {
			if(mongo == null) mongo = mongoConnector.getClient();
		} catch (UnknownHostException e) {
			e.printStackTrace();
		}
		return (mongo.getDB("hypercube")).getCollection(collName);
	}
	
	public Date getExpireTime(){
		//Set Cut Off Date
		Calendar cutoff = Calendar.getInstance();
		
		System.out.println("current time: " + cutoff.getTime());
		
//		cutoff.add(Calendar.DATE, 0);
//		cutoff.add(Calendar.HOUR_OF_DAY, 0);
//		cutoff.add(Calendar.MINUTE, 0);
		cutoff.add(Calendar.SECOND, 10);
		System.out.println("expireTime: " + cutoff.getTime());
		
		return cutoff.getTime();

	}
	
	public void insertSmsCode(String npId, String code) {		
		// TODO Auto-generated method stub
		BasicDBObject document = new BasicDBObject();
		String timeStamp = dateFormatter.format(this.getExpireTime());
		document.put("expireAt", timeStamp);
		document.put("npId", npId);
		document.put("code", code);
		
//		WriteConcern concern = new WriteConcern();
		DBCollection coll_record = this.getDBCollection("smscode");
//		coll_record.setWriteConcern(concern.FSYNC_SAFE);
		coll_record.insert(document);

		System.out.println(document);
		System.out.println("success!");
	}
	
	public void deleteRecord(String filename) {
		DBCollection collection = this.getDBCollection("record");
		BasicDBObject query = new BasicDBObject();
		query.append("filename", filename);
		collection.remove(query);
	}
	
	private String getSmsCode(String npId) {
		BasicDBObject query = new BasicDBObject();
		query.put("npId", npId);
		String processDescription = "NA";
		String stopTheClockScan = "No";
		DBCollection coll_smscode = this.getDBCollection("smscode");
		try(DBCursor cursor = coll_smscode.find(query)){
			while(cursor.hasNext()) {
				DBObject object = cursor.next();
			  return (String) object.get("code");
			}
		}
		return null;
	}
	
	public static void main(String[] args){
		MongoTest mongoTest = new MongoTest();
//		mongoTest.insertSmsCode("24680", "1234");
		
		
		System.out.println("getSmsCode: " + mongoTest.getSmsCode("24680"));
		
	}
}

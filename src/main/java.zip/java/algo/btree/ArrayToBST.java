package algo.btree;

public class ArrayToBST {
	public Node sortedArrayToBST(int[] num) {
		if (num.length == 0)
			return null;
		return sortedArrayToBST(num, 0, num.length - 1);
	}
 
	public Node sortedArrayToBST(int[] num, int start, int end) {
		if (start > end)
			return null;
 
		int mid = (start + end) / 2;
		Node root = new Node(num[mid]);
		root.left = sortedArrayToBST(num, start, mid - 1);
		root.right = sortedArrayToBST(num, mid + 1, end);
 
		return root;
	}
	
	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int [] nums = {1,3,5,7,9,8,6,4,2};
		
		ArrayToBST test = new ArrayToBST();
		Node node = test.sortedArrayToBST(nums);
		
		
		
	}

}

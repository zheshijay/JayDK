package algo.btree;

public class Node {
			int val;
			Node left, right;
			Node(int val){
				this.val = val;
				this.left = null;
				this.right = null;
			}
}

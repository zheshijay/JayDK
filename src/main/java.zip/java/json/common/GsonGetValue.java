package json.common;

import org.codehaus.jettison.json.JSONException;

public class GsonGetValue {
	public static void main(String args[]) throws JSONException{
		String jsonStr = "";
		
	}
}

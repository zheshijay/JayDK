package oauth2;

/*
 * CustomInformation for enrollment
 */
public class CustomInformation {
		private String emailId;
		private String flagInd1;
		private String flagLevel1;
		private String flagNum1;
		private String flagType1;
		private String reasonNum1;
		private String suffix;
		private String surname;
		public String getEmailId() {
			return emailId;
		}
		public void setEmailId(String emailId) {
			this.emailId = emailId;
		}
		public String getFlagInd1() {
			return flagInd1;
		}
		public void setFlagInd1(String flagInd1) {
			this.flagInd1 = flagInd1;
		}
		public String getFlagLevel1() {
			return flagLevel1;
		}
		public void setFlagLevel1(String flagLevel1) {
			this.flagLevel1 = flagLevel1;
		}
		public String getFlagNum1() {
			return flagNum1;
		}
		public void setFlagNum1(String flagNum1) {
			this.flagNum1 = flagNum1;
		}
		public String getFlagType1() {
			return flagType1;
		}
		public void setFlagType1(String flagType1) {
			this.flagType1 = flagType1;
		}
		public String getReasonNum1() {
			return reasonNum1;
		}
		public void setReasonNum1(String reasonNum1) {
			this.reasonNum1 = reasonNum1;
		}
		public String getSuffix() {
			return suffix;
		}
		public void setSuffix(String suffix) {
			this.suffix = suffix;
		}
		public String getSurname() {
			return surname;
		}
		public void setSurname(String surname) {
			this.surname = surname;
		}
		
}


package oauth2;

public class WebSessionContext {

}

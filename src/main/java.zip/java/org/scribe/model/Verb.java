package org.scribe.model;

public enum Verb {
	GET, POST, PUT, DELETE, HEAD, OPTIONS, TRACE, PATCH
}

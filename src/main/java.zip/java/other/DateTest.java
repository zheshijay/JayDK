package other;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class DateTest {
	public static void main(String[] args) throws ParseException{
		
//		String date1 = "01/07/2015 14:58:07";
//		String date2 = "01/07/2015 14:58:08";
//		
//		Date date11 = new Date(date1);
//		Date date22 = new Date(date2);
//		System.out.println(date11.compareTo(date22));
//		System.out.println(date22.compareTo(date11));
		
		
		
		
		
//		SimpleDateFormat psiFileDateFormat = new SimpleDateFormat("yyyyMMdd"); 	
//		String filename = "20150128041704_ProofOfInduction_D";
//		String dateStr = filename.substring(0,8);
//		System.out.println(dateStr);
//		SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd");
//		Date date = sdf.parse(filename.substring(0,8));
//		
//		System.out.println(date.before(new Date()));
		
		
//		System.out.println(yearStr);
//		System.out.println(monthStr);
//		System.out.println(dayStr);
//		Date date = psiFileDateFormat.parse(dateStr);
//		
//		System.out.println("String date is: " + dateStr);
//		System.out.println(date.getYear());
	}
}

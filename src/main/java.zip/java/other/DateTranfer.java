package other;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class DateTranfer {
	public static void main(String[] args) throws ParseException{
		
		String date1_str = "20150201";
		String date2_str = "02/01/2015 03:21:46";
		
		SimpleDateFormat recordDateFormatter = new SimpleDateFormat("MM/dd/yyyy HH:mm:ss");
		SimpleDateFormat psiRecordDateFormatter = new SimpleDateFormat("yyyyMMdd");
		
//		Date date1 = new Date(date1_str);
//		Date date2 = new Date(date2_str);
//		
//		System.out.println(date1.toGMTString() );
//		System.out.println(date2.toGMTString() ); 
		
		Date psi_date = psiRecordDateFormatter.parse(date1_str);
		String transferedPsiDate = recordDateFormatter.format(psi_date.getTime());
		
		System.out.println("psi_timeStamp1: " + transferedPsiDate);
		
		
		
		
		
//		SimpleDateFormat psiFileDateFormat = new SimpleDateFormat("yyyyMMdd"); 	
//		String filename = "20150128041704_ProofOfInduction_D";
//		String dateStr = filename.substring(0,8);
//		System.out.println(dateStr);
//		SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd");
//		Date date = sdf.parse(filename.substring(0,8));
//		
//		System.out.println(date.before(new Date()));
		
		
//		System.out.println(yearStr);
//		System.out.println(monthStr);
//		System.out.println(dayStr);
//		Date date = psiFileDateFormat.parse(dateStr);
//		
//		System.out.println("String date is: " + dateStr);
//		System.out.println(date.getYear());
	}
}

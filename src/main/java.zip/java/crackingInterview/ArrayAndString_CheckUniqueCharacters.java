package crackingInterview;

import java.util.HashSet;

public class ArrayAndString_CheckUniqueCharacters {

	//use data structure
	public static boolean isUniqueChars(String inputstring) {
		boolean result=false;
		
		System.out.println("inputstring is: " + inputstring);
		
		HashSet < Character> uniquecharset= new HashSet();
		
		for(int i=0;i < inputstring.length();i++)
		{
			result = uniquecharset.add(inputstring.charAt(i));
			  if (result == false)
		            break;
		}
		return result;
	}


	//without any data structure
	public static boolean isUniqueChars2(String str) {
		boolean[] char_set = new boolean[256];
		for (int i = 0; i < str.length(); i++) {
			int val = str.charAt(i);
			if (char_set[val]) return false;
			char_set[val] = true;
		}
		return true;
	}

	public static void main(String[] args){
		ArrayAndString_CheckUniqueCharacters newInstance = new ArrayAndString_CheckUniqueCharacters();
		//		System.out.println(newInstance.isUniqueChars2("abcdeb"));
		System.out.println(newInstance.isUniqueChars("abcde"));

	}


}

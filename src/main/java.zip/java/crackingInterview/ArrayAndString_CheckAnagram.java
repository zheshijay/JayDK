package crackingInterview;

import java.util.Arrays;

public class ArrayAndString_CheckAnagram {

	
	
	public boolean isAnagram(String firstWord, String secondWord) {
//	     char[] word1 = firstWord.replaceAll("[\\s]", "").toCharArray();
//	     char[] word2 = secondWord.replaceAll("[\\s]", "").toCharArray();
	     char[] word1 = firstWord.replaceAll("[\\s]", "").toCharArray();
	     char[] word2 = secondWord.replaceAll("[\\s]", "").toCharArray();
	     Arrays.sort(word1);
	     Arrays.sort(word2);
	     return Arrays.equals(word1, word2);
	}
	
	public static void main(String[] args){
		ArrayAndString_CheckAnagram newInstance = new ArrayAndString_CheckAnagram();

		System.out.println();

	}
}

package crackingInterview;

public class ArrayAndString_ReverseCStyleString 
{
	public static void main(String[] args) 
	{
		String str = "abcd ";
		char[] myChar = str.toCharArray();
		System.out.println(str);
		int p1 = 0;
		int p2 = myChar.length -1;

		while(p1<p2)
		{
			char temp = myChar[p1];
			myChar[p1]= myChar[p2];
			myChar[p2] = temp;

			p1++;
			p2--;
		}

		str = str.copyValueOf(myChar);

		System.out.println(str);
	}
}
package crackingInterview;

import java.util.HashSet;
import java.util.Set;

public class ArrayAndString_removeDuplicates {

	public static void removeDup(char[] target){
		String string = "aabbccdefatafaz";

		char[] chars = string.toCharArray();
		Set<Character> charSet = new HashSet<Character>();
		for (char c : chars) {
		    charSet.add(c);
		}

		StringBuilder sb = new StringBuilder();
		for (Character character : charSet) {
		    sb.append(character);
		}
		System.out.println(sb.toString());

	}

	//without addtional buffer
	public String removeDup2(String target){

		if(target == null)
			return null;

		if(target.length() <= 1)
			return target;

		char [] str = target.toCharArray();
		boolean [] flag = new boolean[256];
		int tail = 0;
		int cur = 0;

		while(cur < str.length){
			if(flag[str[cur]] == false){
				flag[str[cur]] = true;
				str[tail] = str[cur];
				tail++;
				cur++;

			}
			else
				cur++;
		}

		return new String(str, 0, tail);
	}

	public static void main(String[] args) 
	{
		ArrayAndString_removeDuplicates newIns = new ArrayAndString_removeDuplicates();
		char[] testChar = new char[]{'a','b','c','a','a'};
		
		newIns.removeDup(testChar);
		
		System.out.println(testChar);

	}
}

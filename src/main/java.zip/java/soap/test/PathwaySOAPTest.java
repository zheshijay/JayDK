package soap.test;

import java.io.StringWriter;

import javax.xml.soap.*;
import javax.xml.transform.*;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.*;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

//import org.mule.api.MuleEventContext;
//import org.mule.api.MuleMessage;
//import org.mule.api.lifecycle.Callable;
//import org.mule.util.StringUtils;
//import org.slf4j.Logger;

import org.w3c.dom.DOMImplementation;
import org.w3c.dom.Document;
import org.w3c.dom.Element;

public class PathwaySOAPTest {

	private String tokenId = "INI11";
	
	private static SOAPMessage createSOAPRequest() throws Exception {
		MessageFactory messageFactory = MessageFactory.newInstance();
		SOAPMessage soapMessage = messageFactory.createMessage();
		SOAPPart soapPart = soapMessage.getSOAPPart();

		String serverURI = "http://summit.fiserv.com/cfg/CommandSchema/sisCommands.xsd";

		// SOAP Envelope
		SOAPEnvelope envelope = soapPart.getEnvelope();
		envelope.addNamespaceDeclaration("schemaLocation", serverURI);

		/*
        Constructed SOAP Request Message:
        <SOAP-ENV:Envelope xmlns:SOAP-ENV="http://schemas.xmlsoap.org/soap/envelope/" 	xmlns:example="http://ws.cdyne.com/">
            <SOAP-ENV:Header/>
            <SOAP-ENV:Body>
                <example:VerifyEmail>
                    <example:email>mutantninja@gmail.com</example:email>
                    <example:LicenseKey>123</example:LicenseKey>
                </example:VerifyEmail>
            </SOAP-ENV:Body>
        </SOAP-ENV:Envelope>
		 */

		// SOAP Body
		SOAPBody soapBody = envelope.getBody();
		SOAPElement soapBodyElem = soapBody.addChildElement("VerifyEmail", "example");
		SOAPElement soapBodyElem1 = soapBodyElem.addChildElement("email", "example");
		soapBodyElem1.addTextNode("mutantninja@gmail.com");
		SOAPElement soapBodyElem2 = soapBodyElem.addChildElement("LicenseKey", "example");
		soapBodyElem2.addTextNode("123");

		MimeHeaders headers = soapMessage.getMimeHeaders();
		headers.addHeader("SOAPAction", serverURI  + "VerifyEmail");

		soapMessage.saveChanges();

		/* Print the request message */
		System.out.print("Request SOAP Message = ");
		soapMessage.writeTo(System.out);
		System.out.println();

		return soapMessage;
	}


	//	private static SOAPMessage createSOAPRequest() throws Exception {
	//		MessageFactory messageFactory = MessageFactory.newInstance();
	//		SOAPMessage soapMessage = messageFactory.createMessage();
	//		SOAPPart soapPart = soapMessage.getSOAPPart();
	//		
	//		String serverURI = "http://ws.cdyne.com/";
	//		
	//		// SOAP Envelope
	//		SOAPEnvelope envelope = soapPart.getEnvelope();
	//		envelope.addNamespaceDeclaration("example", serverURI);
	//
	//		/*
	//        Constructed SOAP Request Message:
	//        <SOAP-ENV:Envelope xmlns:SOAP-ENV="http://schemas.xmlsoap.org/soap/envelope/" 	xmlns:example="http://ws.cdyne.com/">
	//            <SOAP-ENV:Header/>
	//            <SOAP-ENV:Body>
	//                <example:VerifyEmail>
	//                    <example:email>mutantninja@gmail.com</example:email>
	//                    <example:LicenseKey>123</example:LicenseKey>
	//                </example:VerifyEmail>
	//            </SOAP-ENV:Body>
	//        </SOAP-ENV:Envelope>
	//		 */
	//
	//		// SOAP Body
	//		SOAPBody soapBody = envelope.getBody();
	//		SOAPElement soapBodyElem = soapBody.addChildElement("VerifyEmail", "example");
	//		SOAPElement soapBodyElem1 = soapBodyElem.addChildElement("email", "example");
	//		soapBodyElem1.addTextNode("mutantninja@gmail.com");
	//		SOAPElement soapBodyElem2 = soapBodyElem.addChildElement("LicenseKey", "example");
	//		soapBodyElem2.addTextNode("123");
	//
	//		MimeHeaders headers = soapMessage.getMimeHeaders();
	//		headers.addHeader("SOAPAction", serverURI  + "VerifyEmail");
	//
	//		soapMessage.saveChanges();
	//
	//		/* Print the request message */
	//		System.out.print("Request SOAP Message = ");
	//		soapMessage.writeTo(System.out);
	//		System.out.println();
	//
	//		return soapMessage;
	//	}

	/**
	 * Method used to print the SOAP Response
	 */
	private static void printSOAPResponse(SOAPMessage soapResponse) throws Exception {
		TransformerFactory transformerFactory = TransformerFactory.newInstance();
		Transformer transformer = transformerFactory.newTransformer();
		Source sourceContent = soapResponse.getSOAPPart().getContent();
		System.out.print("\nResponse SOAP Message = ");
		StreamResult result = new StreamResult(System.out);
		transformer.transform(sourceContent, result);
	}



	//	   public Document prepareFDINRequest(String accountNo, String surname){
	//	        Document xmlDoc = null;
	//	        Element element = null;
	//	        
	//	        try {
	//	        	
	//	        		//Default values: surname=ZZ, flagLevel1=M
	////	        		if ((surname==null) || StringUtils.isEmpty(surname) || StringUtils.isBlank(surname) ){
	////	        			surname= InstantConstants.SURNAME_DEFAULT; 
	////	        		}
	//	        		String flagLevel = InstantConstants.FLAGLEVEL1_DEFAULT; 
	//
	//	        		StringBuilder strBuilder = new StringBuilder();
	//	        		strBuilder.append("<Summit xmlns=\"http://summit.fiserv.com\" xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\" xsi:schemaLocation=\"http://summit.fiserv.com/cfg/CommandSchema/sisCommands.xsd\">");
	//	        		strBuilder.append("<Spectrum><CommandRq><RequestHeader><Teller><ID>");
	//	        		strBuilder.append(tokenId);
	//	        		strBuilder.append("</ID></Teller><Override>0</Override></RequestHeader>");
	//	        		strBuilder.append("<FDINRq>");
	//	        		strBuilder.append("<Account>");
	//	        		strBuilder.append(accountNo);
	//	        		strBuilder.append("</Account>");        		
	//	        		strBuilder.append("<Surname>"); 
	//	        		strBuilder.append(surname);
	//	        		strBuilder.append("</Surname>");
	//	        		strBuilder.append("<FlagLevel>"); 
	//	        		strBuilder.append(flagLevel);
	//	        		strBuilder.append("</FlagLevel>");
	//	        		strBuilder.append("</FDINRq>");
	//	        		strBuilder.append("</CommandRq></Spectrum></Summit>");
	//	        		
	//	        		
	//	        		System.out.println("strBuilder is: " + strBuilder);
	////	        		LOGGER.debug("XMLRequest=" + strBuilder.toString());
	//	        		/************** Sample XML request - Input data ********************
	//	                <FDINRq>
	//		                <Account>9729</Account>
	//		                <Surname>CL</Surname>
	//		                <FlagLevel>M</FlagLevel>
	//	            	</FDINRq>
	//	        		******************************************************/
	//		            DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
	//		            factory.setNamespaceAware(true);
	//		            DocumentBuilder docBuilder  = factory.newDocumentBuilder();
	//		            DOMImplementation impl = docBuilder.getDOMImplementation();
	//
	//		            // Set root element
	//		            xmlDoc = impl.createDocument(InstantConstants.NAMESPACE_URI, InstantConstants.NAMESPACE_PREFIX + ":Envelope", null);  
	//		            
	//		            System.out.println("InstantConstants.NAMESPACE_URI is: " + InstantConstants.NAMESPACE_URI);
	//		            System.out.println("InstantConstants.NAMESPACE_PREFIX is: " + InstantConstants.NAMESPACE_PREFIX);
	//		            System.out.println("xmlDoc is: " + xmlDoc.toString());
	//		            
	//		        	Element rootElement = xmlDoc.getDocumentElement();
	//		        	rootElement.setAttributeNS(InstantConstants.SOAP_ATTRIB_NS, "xmlns:" + InstantConstants.NAMESPACE_PREFIX, InstantConstants.NAMESPACE_URI);
	//		        	rootElement.setAttributeNS(InstantConstants.SOAP_ATTRIB_NS, "xmlns:xsi", InstantConstants.SOAP_XSI_NS);
	//		        	rootElement.setAttributeNS(InstantConstants.SOAP_ATTRIB_NS, "xmlns:xsd", InstantConstants.SOAP_XML_NS);
	//		        	rootElement.setAttributeNS(InstantConstants.SOAP_ATTRIB_NS, "xmlns:urn", InstantConstants.SOAP_PATHWAYS_NS2_NS);
	//		        	
	//		        	 System.out.println("rootElement is: " + rootElement.toString());
	//		    		
	//		        	// Set header/body elements
	//		    		Element header = xmlDoc.createElement(InstantConstants.NAMESPACE_PREFIX + ":Header");
	//		    		rootElement.appendChild(header);
	//		    		
	//		    		Element body = xmlDoc.createElement(InstantConstants.NAMESPACE_PREFIX + ":Body");
	//		    		rootElement.appendChild(body);
	//		    		// Set xmlRequest element - FLAG command 
	//		    		Element elementCmd = xmlDoc.createElement("urn:submitXMLCommand");
	//		    		body.appendChild(elementCmd);
	//		    		element = xmlDoc.createElement("xmlRequest");
	//		    		element.appendChild(xmlDoc.createTextNode(strBuilder.toString()));
	//		    		elementCmd.appendChild(element);
	//		    		
	//
	//		    		System.out.println("final xmlDoc is: " + this.getStringFromDocument(xmlDoc).replaceAll("&gt;", ">").replaceAll("&lt;", "<"));
	//		    		
	//		    		return xmlDoc;
	//
	//
	//	        } catch (ParserConfigurationException e) {
	////	        	LOGGER.error("FdinReqParserComponent XML parse error: " + e.getMessage());
	//		    } catch (Exception e) {
	////		    	LOGGER.error("FdinReqParserComponent Exeption: " + e.getMessage());
	//		    }
	//	        return null;    	
	//	    }

	public Document prepareFDINRequest(String accountNo, String surname){
		Document xmlDoc = null;
		Element element = null;

		try {

			//Default values: surname=ZZ, flagLevel1=M
			if ((surname==null) || StringUtils.isEmpty(surname) || StringUtils.isBlank(surname) ){
				surname= InstantConstants.SURNAME_DEFAULT; 
			}
			String flagLevel = InstantConstants.FLAGLEVEL1_DEFAULT; 

			StringBuilder strBuilder = new StringBuilder();
			strBuilder.append("<Summit xmlns=\"http://summit.fiserv.com\" xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\" xsi:schemaLocation=\"http://summit.fiserv.com/cfg/CommandSchema/sisCommands.xsd\">");
			strBuilder.append("<Spectrum><CommandRq><RequestHeader><Teller><ID>");
			strBuilder.append(tokenId);
			strBuilder.append("</ID></Teller><Override>0</Override></RequestHeader>");
			strBuilder.append("<FDINRq>");
			strBuilder.append("<Account>");
			strBuilder.append(accountNo);
			strBuilder.append("</Account>");        		
			strBuilder.append("<Surname>"); 
			strBuilder.append(surname);
			strBuilder.append("</Surname>");
			strBuilder.append("<FlagLevel>"); 
			strBuilder.append(flagLevel);
			strBuilder.append("</FlagLevel>");
			strBuilder.append("</FDINRq>");
			strBuilder.append("</CommandRq></Spectrum></Summit>");
			//	        		LOGGER.debug("XMLRequest=" + strBuilder.toString());
			/************** Sample XML request - Input data ********************
	                <FDINRq>
		                <Account>9729</Account>
		                <Surname>CL</Surname>
		                <FlagLevel>M</FlagLevel>
	            	</FDINRq>
			 ******************************************************/
			DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
			factory.setNamespaceAware(true);
			DocumentBuilder docBuilder  = factory.newDocumentBuilder();
			DOMImplementation impl = docBuilder.getDOMImplementation();

			// Set root element
			xmlDoc = impl.createDocument(InstantConstants.NAMESPACE_URI, InstantConstants.NAMESPACE_PREFIX + ":Envelope", null);                      
			Element rootElement = xmlDoc.getDocumentElement();
			rootElement.setAttributeNS(InstantConstants.SOAP_ATTRIB_NS, "xmlns:" + InstantConstants.NAMESPACE_PREFIX, InstantConstants.NAMESPACE_URI);
			rootElement.setAttributeNS(InstantConstants.SOAP_ATTRIB_NS, "xmlns:xsi", InstantConstants.SOAP_XSI_NS);
			rootElement.setAttributeNS(InstantConstants.SOAP_ATTRIB_NS, "xmlns:xsd", InstantConstants.SOAP_XML_NS);
			rootElement.setAttributeNS(InstantConstants.SOAP_ATTRIB_NS, "xmlns:urn", InstantConstants.SOAP_PATHWAYS_NS2_NS);

			// Set header/body elements
			Element header = xmlDoc.createElement(InstantConstants.NAMESPACE_PREFIX + ":Header");
			rootElement.appendChild(header);

			Element body = xmlDoc.createElement(InstantConstants.NAMESPACE_PREFIX + ":Body");
			rootElement.appendChild(body);
			// Set xmlRequest element - FLAG command 
			Element elementCmd = xmlDoc.createElement("urn:submitXMLCommand");
			body.appendChild(elementCmd);
			element = xmlDoc.createElement("xmlRequest");
			element.appendChild(xmlDoc.createTextNode(strBuilder.toString()));
			elementCmd.appendChild(element);
			System.out.println("final xmlDoc is: " + this.getStringFromDocument(xmlDoc).replaceAll("&gt;", ">").replaceAll("&lt;", "<"));

			return xmlDoc;

		} catch (ParserConfigurationException e) {
			System.out.println("FdinReqParserComponent XML parse error: " + e.getMessage());
		} catch (Exception e) {
			System.out.println("FdinReqParserComponent Exeption: " + e.getMessage());
		}
		return null;    	
	}

	public Document prepareFLAGRequest(
			String accountNo, 
			String surname, 
			String suffix,
			String flagInd,	
			String flagLevel, 
			String flagType, 
			String reasonNum){
		Document xmlDoc = null;
		Element element = null;

		try {

			//Default values: surname=ZZ, suffix=00, flagLevel1=M, flagType1=C, FlagNum1=69, flagInd1 = S/C
			//if (flagLevel==null) flagLevel="M";
			//if (flagType==null)  flagType="C";
			if ((surname==null) || StringUtils.isEmpty(surname) || StringUtils.isBlank(surname) ){
				surname= InstantConstants.SURNAME_DEFAULT; 
			}
			suffix    = InstantConstants.SUFFIX_DEFAULT;  
			flagLevel = InstantConstants.FLAGLEVEL1_DEFAULT; 
			flagType  = InstantConstants.FLAGTYPE1_DEFAULT;  
			reasonNum = InstantConstants.REASONNUM_DEFAULT; 

			StringBuilder strBuilder = new StringBuilder();
			strBuilder.append("<Summit xmlns=\"http://summit.fiserv.com\" xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\" xsi:schemaLocation=\"http://summit.fiserv.com/cfg/CommandSchema/sisCommands.xsd\">");
			strBuilder.append("<Spectrum><CommandRq><RequestHeader><Teller><ID>");
			strBuilder.append(tokenId);
			strBuilder.append("</ID></Teller><Override>0</Override></RequestHeader>");
			strBuilder.append(InstantConstants.FLAGRQ_START);
			strBuilder.append("<Account>");
			strBuilder.append(accountNo);
			strBuilder.append("</Account>");        		
			strBuilder.append("<Suffix>");
			strBuilder.append(suffix);
			strBuilder.append("</Suffix>");
			strBuilder.append("<Surname>"); 
			strBuilder.append(surname);
			strBuilder.append("</Surname>");
			strBuilder.append("<FlagSetOrClear1>"); 
			strBuilder.append(flagInd);
			strBuilder.append("</FlagSetOrClear1>");
			strBuilder.append("<FlagLevel1>"); 
			strBuilder.append(flagLevel);
			strBuilder.append("</FlagLevel1>");
			strBuilder.append("<FlagType1>");
			strBuilder.append(flagType);
			strBuilder.append("</FlagType1>");
			strBuilder.append("<FlagNum1>"); 
			strBuilder.append(InstantConstants.FLAGNUM1_DEFAULT);
			strBuilder.append("</FlagNum1>");
			strBuilder.append("<ReasonNum1>"); 
			strBuilder.append(reasonNum);
			strBuilder.append("</ReasonNum1>");
			strBuilder.append(InstantConstants.FLAGRQ_END);
			strBuilder.append("</CommandRq></Spectrum></Summit>");
			System.out.println("XMLRequest=" + strBuilder.toString());
			/************** Sample XML request - Input data ********************
<FLAGRq>
<Account>9729</Account>
<Suffix>00</Suffix>
<Surname>CL</Surname>
<FlagSetOrClear1>S</FlagSetOrClear1>
<FlagLevel1>M</FlagLevel1>
<FlagType1>C</FlagType1>
<FlagNum1>69</FlagNum1>
<ReasonNum1></ReasonNum1>
</FLAGRq>
			 ******************************************************/
			DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
			factory.setNamespaceAware(true);
			DocumentBuilder docBuilder  = factory.newDocumentBuilder();
			DOMImplementation impl = docBuilder.getDOMImplementation();

			// Set root element
			xmlDoc = impl.createDocument(InstantConstants.NAMESPACE_URI, InstantConstants.NAMESPACE_PREFIX + ":Envelope", null);                      
			Element rootElement = xmlDoc.getDocumentElement();
			rootElement.setAttributeNS(InstantConstants.SOAP_ATTRIB_NS, "xmlns:" + InstantConstants.NAMESPACE_PREFIX, InstantConstants.NAMESPACE_URI);
			rootElement.setAttributeNS(InstantConstants.SOAP_ATTRIB_NS, "xmlns:xsi", InstantConstants.SOAP_XSI_NS);
			rootElement.setAttributeNS(InstantConstants.SOAP_ATTRIB_NS, "xmlns:xsd", InstantConstants.SOAP_XML_NS);
			rootElement.setAttributeNS(InstantConstants.SOAP_ATTRIB_NS, "xmlns:urn", InstantConstants.SOAP_PATHWAYS_NS2_NS);

			// Set header/body elements
			Element header = xmlDoc.createElement(InstantConstants.NAMESPACE_PREFIX + ":Header");
			rootElement.appendChild(header);

			Element body = xmlDoc.createElement(InstantConstants.NAMESPACE_PREFIX + ":Body");
			rootElement.appendChild(body);
			// Set xmlRequest element - FLAG command 
			Element elementCmd = xmlDoc.createElement("urn:submitXMLCommand");
			body.appendChild(elementCmd);
			element = xmlDoc.createElement("xmlRequest");
			element.appendChild(xmlDoc.createTextNode(strBuilder.toString()));
			elementCmd.appendChild(element);
			return xmlDoc;


		} catch (ParserConfigurationException e) {
			System.out.println("RequestParserComponent XML parse error: " + e.getMessage());
		} catch (Exception e) {
			System.out.println("RequestParserComponent Exeption: " + e.getMessage());
		}
		return null;    	
	}

	//method to convert Document to String
	public String getStringFromDocument(Document doc)
	{
		try
		{
			DOMSource domSource = new DOMSource(doc);
			StringWriter writer = new StringWriter();
			StreamResult result = new StreamResult(writer);
			TransformerFactory tf = TransformerFactory.newInstance();
			Transformer transformer = tf.newTransformer();
			transformer.transform(domSource, result);
			return writer.toString();
		}
		catch(TransformerException ex)
		{
			ex.printStackTrace();
			return null;
		}
	} 
	
	
	/**
	 * Starting point for the SAAJ - SOAP Client Testing
	 */
	public static void main(String args[]) {
		try {
			// Create SOAP Connection
			//			SOAPConnectionFactory soapConnectionFactory = SOAPConnectionFactory.newInstance();
			//			SOAPConnection soapConnection = soapConnectionFactory.createConnection();
			//
			//			// Send SOAP Message to SOAP Server
			//			String url = "http://ws.cdyne.com/emailverify/Emailvernotestemail.asmx";
			//			SOAPMessage soapResponse = soapConnection.call(createSOAPRequest(), url);
			//
			//			// Process the SOAP Response
			//			printSOAPResponse(soapResponse);
			//			soapConnection.close();

			PathwaySOAPTest test = new PathwaySOAPTest();
//			test.prepareFDINRequest("12345", "Zhe");
			
			Document flagDoc = test.prepareFLAGRequest("31993", null, null, "S", null, null, "t.wood1980@gmail.com");
			System.out.println("final xmlDoc is: " + test.getStringFromDocument(flagDoc).replaceAll("&gt;", ">").replaceAll("&lt;", "<"));
			
		} catch (Exception e) {
			System.err.println("Error occurred while sending SOAP Request to Server");
			e.printStackTrace();
		}
	}



}




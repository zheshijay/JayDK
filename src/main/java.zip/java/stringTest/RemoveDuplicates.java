package stringTest;

import java.util.ArrayList;
import java.util.HashSet;

public class RemoveDuplicates {

	public static void main(String[] args){
		
		
		
		
		
		
//		ArrayList<String> allUpdatedJobs = new ArrayList<String>();
//		
//		allUpdatedJobs.add("demo_11111");
//		allUpdatedJobs.add("demo_11111");
//		allUpdatedJobs.add("demo_11111");
//		
//		allUpdatedJobs.add("demo_22222");
//		
//		//remove duplicates
//		HashSet hs = new HashSet();
//		hs.addAll(allUpdatedJobs);
//		allUpdatedJobs.clear();
//		allUpdatedJobs.addAll(hs);
//		
//		
//		System.out.println(allUpdatedJobs);

	}
}

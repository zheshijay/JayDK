package stringTest;

public class SplitTest {
	public static void main(String [] args){
		
		String status = "B|E";
//		String status2 = "B,E";
		String[] statusArray = status.split("\\|");
//		String[] statusArray2 = status2.split(",");
		
		System.out.println(statusArray.length);
		
		System.out.println(statusArray[0]);
		System.out.println(statusArray[1]);
//		System.out.println(statusArray2[0]);
		
		String encryptedAcctNums = "ToRDVjTdz3__XyhMX9ezjw";
		
		String[] encryptedAcctNumsArray = encryptedAcctNums.split(",");
		for(String str: encryptedAcctNumsArray){
				System.out.println("values: " + str);
		}	
		
	}
}

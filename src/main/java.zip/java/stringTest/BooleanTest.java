package stringTest;

public class BooleanTest {
	public static void main(String[] args){
		String firstName = "JOSEPH M TUCCITTO";
		String lastName = null;
		
		System.out.println("123" + null); 
		
		System.out.println((firstName==null?"":firstName) + " " + (lastName==null?"":lastName)); 
	}
}

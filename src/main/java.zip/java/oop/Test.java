package oop;

public class Test {
	private String infoXchange;
}
